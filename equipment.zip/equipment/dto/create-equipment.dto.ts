import { IsOptional, IsString, IsNumber } from "class-validator";

export class CreateEquipmentDto {

  @IsOptional()
  @IsString()
  operation: string; 

  @IsOptional()
  @IsString()
  unit: string; 

  @IsOptional()
  @IsString()
  plate: string; 

  @IsOptional()
  @IsString()
  category: string; 

  @IsOptional()
  @IsString()
  material: string; 

  @IsOptional()
  @IsString()
  provider: string; 

  @IsOptional()
  @IsString()
  brand: string; 

  @IsOptional()
  @IsString()
  model: string; 

  @IsOptional()
  @IsString()
  serial_number: string; 

  @IsOptional()
  @IsNumber()
  quantity: number; 

  @IsOptional()
  installation_at: Date; 

  @IsOptional()
  retired_at: Date; 

  @IsOptional()
  expires_at: Date; 

  @IsOptional()
  calibration_at: Date; 

  @IsOptional()
  @IsString()
  status: string; 
}