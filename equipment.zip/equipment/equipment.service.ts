import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateEquipmentDto } from './dto/create-equipment.dto';
import { UpdateEquipmentDto } from './dto/update-equipment.dto';
import { PrismaService } from 'src/prisma.service';
import { PaginationDto } from 'src/common/dto/pagination.dto';
import { GlobalFunctions } from 'src/common/functions/global-function';
import { ResponseScheme } from 'src/common/interfaces/response.interface';

@Injectable()
export class EquipmentService {

    constructor(private prisma: PrismaService, private readonly globalFunctions: GlobalFunctions) { }
    //resp scheme for returning data in response
    private resp: ResponseScheme = {
        error: false,
        message: '',
        statusCode: 200,
        data: {},
    }

    async create(createEquipmentDto: CreateEquipmentDto) {
        this.resp.data = {}
        this.resp.error = false
        try {
            this.resp.statusCode = 200;

            const createdEquipment = await this.prisma.equipment.create({
                data: {
                    operation: createEquipmentDto.operation,
                    unit: createEquipmentDto.unit,
                    plate: createEquipmentDto.plate,
                    category: createEquipmentDto.category,
                    material: createEquipmentDto.material,
                    provider: createEquipmentDto.provider,
                    brand: createEquipmentDto.brand,
                    model: createEquipmentDto.model,
                    serial_number: createEquipmentDto.serial_number,
                    quantity: createEquipmentDto.quantity,
                    installation_at: createEquipmentDto.installation_at,
                    retired_at: createEquipmentDto.retired_at,
                    expires_at: createEquipmentDto.expires_at,
                    calibration_at: createEquipmentDto.calibration_at,
                    status: createEquipmentDto.status,
                }
            })

            this.resp.message = "Equipo creado";
            this.resp.data = createdEquipment;

        } catch (e) {
            this.resp.error = true
            this.resp.statusCode = 500;
            this.resp.message = JSON.stringify(e);
        }
        return this.resp;
    }

    async findAll(paginationDto: PaginationDto) {
        try {
            this.resp.data = {}
            this.resp.error = false;
            this.resp.statusCode = 200;
            var {
                page = 1,
                limit = 10,
                order = "desc",
                sort = "id",
                filter = "[]",

            } = paginationDto;

            const objectFilter = await this.globalFunctions.getObjectFilterGrid(
                sort,
                order,
                page,
                limit,
                filter
            );

            const offset = await this.globalFunctions.getOffsetByPage(page, limit);
            const data = await this.prisma.equipment.aggregate({
                _count: {
                    id: true,
                },
                where: {
                    deleted_at: null,
                    AND: objectFilter.contains
                },
            });
            const { _count } = data;
            const pages = await this.globalFunctions.getCantPages(_count.id, limit);
            const responseFilter = await this.globalFunctions.getResponseFilter(
                limit,
                order,
                page,
                sort,
                pages,
                _count.id
            );

            const rows = await this.prisma.equipment.findMany({
                select: {
                    id: true,
                    operation: true,
                    unit: true,
                    plate: true,
                    category: true,
                    material: true,
                    provider: true,
                    brand: true,
                    model: true,
                    serial_number: true,
                    quantity: true,
                    installation_at: true,
                    retired_at: true,
                    expires_at: true,
                    calibration_at: true,
                    status: true,
                },
                where: {
                    deleted_at: null,
                    isActive: true,
                    AND: objectFilter.contains,

                },
                skip: offset,
                take: objectFilter.cant,
                orderBy: objectFilter.order,
            });
            this.resp.message = "Equipos encontrados";
            this.resp.data = {
                rows, responseFilter
            }
        } catch (e) {
            console.log({ error: e })
            this.resp.error = true;
            this.resp.message = JSON.stringify(e);
            this.resp.statusCode = 400;
        }
        return this.resp
    }

    async findOne(id: number) {
        try {
            this.resp.data = {}
            this.resp.error = false;
            this.resp.statusCode = 200;

            const equipment = await this.prisma.equipment.findUnique({
                where: {
                    id: id
                }
            });

            if (!equipment) {
                throw new BadRequestException('Equipo no existente');
            }

            this.resp.message = "";
            this.resp.data = equipment;
        } catch (e) {
            this.resp.statusCode = 500;
            this.resp.error = true;
            this.resp.message = JSON.stringify(e);
        }
        return this.resp;
    }

    async update(id: number, updateEquipmentDto: UpdateEquipmentDto) {
        try {
            this.resp.data = {}
            this.resp.error = false;
            this.resp.statusCode = 200;
            const equipmentFind = await this.prisma.equipment.findUnique({
                where: {
                    id: id
                }
            });
            if (!equipmentFind)
                throw new BadRequestException('Equipo no existente');

            const updatedEquipment = await this.prisma.equipment.update({
                where: {
                    id: id
                },
                data: {
                    operation: updateEquipmentDto.operation,
                    unit: updateEquipmentDto.unit,
                    plate: updateEquipmentDto.plate,
                    category: updateEquipmentDto.category,
                    material: updateEquipmentDto.material,
                    provider: updateEquipmentDto.provider,
                    brand: updateEquipmentDto.brand,
                    model: updateEquipmentDto.model,
                    serial_number: updateEquipmentDto.serial_number,
                    quantity: updateEquipmentDto.quantity,
                    installation_at: updateEquipmentDto.installation_at,
                    retired_at: updateEquipmentDto.retired_at,
                    expires_at: updateEquipmentDto.expires_at,
                    calibration_at: updateEquipmentDto.calibration_at,
                    status: updateEquipmentDto.status,
                    updated_at: new Date()
                }
            });
            this.resp.message = "Equipo actualizado";
            this.resp.data = updatedEquipment;
        } catch (e) {
            this.resp.error = true;
            this.resp.statusCode = 500;
            this.resp.message = JSON.stringify(e);
        }
        return this.resp;
    }

    async remove(id: number) {
        try {
            this.resp.data = {}
            this.resp.error = false;
            this.resp.statusCode = 200;
            await this.prisma.equipment.update({
                where: {
                    id: id
                },
                data: {
                    deleted_at: new Date()
                }
            });
            this.resp.message = "Equipo eliminado";
        } catch (e) {
            this.resp.statusCode = 500;
            this.resp.error = true;
            this.resp.message = JSON.stringify(e);
        }
        return this.resp;
    }
}